//programa en C para consultar los datos de la base de datos
//Incluir esta libreria para poder hacer las llamadas en shiva2.upc.es
//#include <my_global.h>
#include <mysql.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <ctype.h>
#include<stdbool.h>  
#include <pthread.h>
// Estructura especial para almacenar resultados de consultas
//Creamos una conexion al servidor MYSQL 
MYSQL_RES *resultado;
int err;
MYSQL_ROW row; 
MYSQL *conn;

int i;
int sockets[100];

int contador; //Para el numero de servicios
int duracion_ultima_partida;
int id_ultima_partida;
char ultima_Frase[250];
int idPartida;

int socketOrigen;
int socketDestino;
char mensaje[300];
char jugador_origen[20];
char jugador_destino[20];
//Estructura necesaria para acceso excluyente
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

//Estructura para almacenar 100 usuarios conectados
typedef struct{ //Clase "Conectado"
	char nombre[20];
	int socket;
}Conectado;

typedef struct{ //Lista de Conectados
	Conectado conectados[100];
	int num;
}ListaConectados;

ListaConectados milista;

//Declaramos la lista de Partidas, de 6 jugadores cada una
typedef struct {
	int ID;
	int numJugadores;
	char tablero[30];
	//Sockets
	char nombre1[20];
	char nombre2[20];
	char nombre3[20];
	char nombre4[20];
	char nombre5[20];
	char nombre6[20];
	int sock[6];
}Partida;

typedef struct {
	Partida Partidas [1000];
	int num;
} ListaPartidas;

ListaPartidas miListaPartidas;

//LISTA DE CONECTADOS
int DameID(char consulta[100], char respuesta[100]) {
	sprintf(consulta, "SELECT COUNT(jugadores.username) FROM jugadores");
	// recogemos el resultado de la consulta
	err = mysql_query(conn, consulta);
	if (err != 0) {
		printf("Error al consultar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	resultado = mysql_store_result(conn);
	row = mysql_fetch_row(resultado);
	if (row == NULL)
		printf("No se han obtenido datos en la consulta\n");
	else {
				printf("Numero de jugadores registrados: %s\n", row[0]);
		sprintf(respuesta, "%s", row[0]);
	}
	// Liberar el resultado antes de salir
	mysql_free_result(resultado);
	
	return 0;  // O cualquier otro código de retorno que necesites
}

int PonConectado(ListaConectados *lista, char nombre[20], int socket) //A�ade a la lista un nuevo conectado
{
	if (lista->num == 100)
	{
		return -1; //Est� la lista llena
	}
	else
	{
		strcpy(lista->conectados[lista->num].nombre, nombre);
		lista->conectados[lista->num].socket = socket;
		lista->num++;
		return 0; //Se ha a�adido correctamente
	}
	
	
}


void Conectados(ListaConectados *lista, char conectados[300]) //Pone en el vector conectados el numero de usuarios en la lista y el usuario de cada jugador separado por /. Devuelve la lista de conectados separados por /
{
	printf("Inicio\n");
	
	sprintf(conectados, "%d", lista->num);
	
	int i;
	//printf("Conectados: %s\n", conectados);
	for(i=0; i<lista->num; i++)
	{
		sprintf(conectados,"%s/%s",conectados, lista->conectados[i].nombre); //%s, conectados
	
	}
	printf("Conectados: %s\n",conectados);
}
int DameIdPartida(char consulta[100], char respuesta[100])//Funci�n que retorna el ID de la partida
{
	
	sprintf(consulta, "SELECT MAX(id_partidas) FROM partidas");
	//recogemos el resultado de la consulta 
	err=mysql_query (conn, consulta);
	resultado = mysql_store_result (conn); 
	row = mysql_fetch_row (resultado);
	
	if(err!=0)
	{
		printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn),mysql_error(conn));
		exit(1);
	}
	
	if (row == NULL)
		printf ("No se han obtenido datos en la consulta\n");
	else
	{
		//El resultado debe ser una matriz con una sola fila
		//y una columna que contiene el numero de partida.
		printf ("ID de partidas: %s\n", row);
		sprintf(respuesta, "%s", row[0]);
	}

//Funci�n para saber la posicion de ese usuario mediante el socket, si esta en la lista devuelve el socket sino devuelve -1
int GetSocket (ListaConectados *lista, char nombre[20])
{
	int i = 0;
	int encontrado = 0;
	while((i < lista->num) && !encontrado)
	{
		if (strcmp(lista->conectados[i].nombre,nombre) == 0)
		{
			encontrado = 1;
		}
		if(!encontrado)
		{
			i = i+1;
		}
	}
	if (encontrado)
	{
		return lista->conectados[i].socket; //Devuelve el socket
	}
	else
	{
		return -1; //No est� en la lista
	}
}

//FUNCIONES B�SICAS DEL CHAT REGISTRAR, INICIO DE SESI�N, DESCONEXI�N, INVITACI�N 

//Funcion desconectar. Elimina de la lista de conectados a quien se desconecta. 
//Guarda en la variable resDesconectar 0/Desconectado y retorna 0 si se desconecta con �xito o -1 si no esta conectado.

int Desconectar(ListaConectados *lista, char nombre[20], char resDesconectar[512])
{
	int posicion = GetSocket (lista,nombre);
	if (posicion == -1)
	{
		return -1; //No est� conectado 
	}
	
	else
	{
		int i;
		for (i = posicion; i < lista->num-1; i++)
		{
			strcpy(lista->conectados[i].nombre, lista->conectados[i+1].nombre);
			lista->conectados[i].socket = lista->conectados[i+1].socket;
		}
		lista->num--;
		sprintf(resDesconectar,"0/Desconectado, hasta la pr�xima");
		return 0;
	}
}

//Funci�n para el bucle de atenci�n al cliente
void *Atencion(void*socket)
{
	int sock_conn;
	int *s;
	s=(int *)socket;
	sock_conn= *s;
	
	char conectado[300];
	int desconectar=0;
	printf("El socket por el cual me comunico es: %d", sock_conn);
	
	//Conexion mediante sockets con el cliente
	int  sock_listen;
	int ret;
	char peticion[512];
	char respuesta[512];
	
	int terminar = 0;
	
	while(terminar == 0) //Bucle de atencion al cliente
	{
		char usuario[80];
		char contrasena[80];
		int id;
		
		ret = read(sock_conn, peticion, sizeof(peticion));
		printf("Recibido \n");
		
		peticion[ret]='\0';
		
		printf("Peticion %s \n", peticion);
		
		char *p = strtok(peticion, "/");
		int codigo = atoi(p);
		int cont;
		char jugador1 [10];
		char jugador2 [10];
		char consulta [80];


//Funcion Iniciar Sesi�n. Guardara inicio de sesi�n con �xito o 1/incorrecto si no se ha podido iniciar sesi�n.


void IniciarSesion(char contrasena[20],char usuario[20], char consulta[80], char respuesta1[512], int codigo, char conectado[300], int sock_conn)
{
	
	printf ("Codigo: %d, Nombre: %s, Contrase�a: %s\n", codigo, usuario, contrasena);
	
	sprintf(consulta, "SELECT jugadores.username, jugadores.pass FROM jugadores WHERE (jugadores.username='%s' AND jugadores.pass='%s')",usuario,contrasena);
	err=mysql_query(conn, consulta);
	if (err!=0)
	{
		printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn),mysql_error(conn));
		exit(1);
	}
	resultado = mysql_store_result(conn);
	row = mysql_fetch_row(resultado);
	printf("ROW= %s\n", row);
	if (row == NULL)
	{
		printf("No se ha obtenido la consulta \n");
		sprintf(respuesta1,"1/Incorrecto");
		write(sock_conn, respuesta1, strlen(respuesta1));
	}
	else
	{
		printf("Inicio de sesion con exito \n");
		sprintf(respuesta1,"1/INICIO DE SESION CON EXITO");
		pthread_mutex_lock( &mutex );
		PonConectado(&milista, usuario, sock_conn);
		pthread_mutex_unlock( &mutex);
	}
}

//Funci�n registrar nuevo usuario.
int Registro (char usuario[20],char contrasena[20], char respuesta2[512], char consulta[80], int id) 
{
	printf("%s\n", usuario);
	sprintf(consulta, "SELECT jugadores.username FROM jugadores WHERE jugadores.username='%s'",usuario);
	printf("Consulta: %s\n", consulta);
	//Consultamos si el usuario esta registrado
	int err =mysql_query (conn, consulta);
	//Recogemos el resultado
	resultado = mysql_store_result (conn);
	row=mysql_fetch_row(resultado);
	
	printf("row: %s\n", row);
	printf("hola %d\n", err);
	
	
	if (row == NULL)
	{
		printf("A�adir usuario: %s\n", usuario);
	
		/*int idJugador = atoi(row[0]);*/
		char insert[150];
		sprintf(insert,"INSERT INTO jugadores (username, pass) VALUES('%s','%s');",usuario,contrasena); 
		err=mysql_query(conn, insert);
		
		if (err!=0)
		{
			printf ("Error al insertar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
			exit (1);
			sprintf(respuesta2,"2/No se ha podido insertar el usuario");          		 
		}
		else
		{
			sprintf(respuesta2,"2/Registrado correctamente");
			printf("Se ha registrado correctamente el usuario: %s\n", usuario);
		}
	}
	else
	{
		sprintf(respuesta2,"2/No se ha podido acceder a la base de datos");
	} 
	
	if (err !=0)
	{
		printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn),mysql_error(conn));
		exit(1);
	}
	
	
}

//Funcion que verifica y almacena en respuesta la respuesta a la invitaci�n. 

int VerificaInvitacion(ListaConectados *lista,ListaPartidas *lista_partidas,char confirmar[10], int socketOrigen,int socketDestino, char respuesta[512], char jugador_origen [20], char jugador_destino[20], int *sock_conn)
{
	lista_partidas->Partidas[idPartida].numJugadores++;
	if (strcmp(confirmar,"Yes") == 0)
	{
		strcpy(lista_partidas->Partidas[idPartida].nombre1,jugador_destino);
		lista_partidas->Partidas[idPartida].sock[0] = GetSocket(lista,jugador_destino);
		printf("sock1: %d",lista_partidas->Partidas[idPartida].sock[0]);
		sprintf(respuesta,"8/Si/%d/%s/%s", idPartida,jugador_origen,jugador_destino);
		if (lista_partidas->Partidas[idPartida].numJugadores == 2)
		{
			
			strcpy(lista_partidas->Partidas[idPartida].nombre2,jugador_origen);
			lista_partidas->Partidas[idPartida].sock[1] = GetSocket(lista,jugador_origen);
			printf("sock2: %d",lista_partidas->Partidas[idPartida].sock[1]);
			sprintf(respuesta, "%s/%s", respuesta, lista_partidas->Partidas[idPartida].nombre2);
		}
		else if (lista_partidas->Partidas[idPartida].numJugadores == 3)
		{
			strcpy(lista_partidas->Partidas[idPartida].nombre3,jugador_origen);
			lista_partidas->Partidas[idPartida].sock[2] = GetSocket(lista,jugador_origen);
			sprintf(respuesta, "%s/%s/%s", respuesta, lista_partidas->Partidas[idPartida].nombre2,lista_partidas->Partidas[idPartida].nombre3);
		}
		else if (lista_partidas->Partidas[idPartida].numJugadores == 4)
		{strcpy(lista_partidas->Partidas[idPartida].nombre4,jugador_origen);
		lista_partidas->Partidas[idPartida].sock[3] = GetSocket(lista,jugador_origen);
		sprintf(respuesta, "%s/%s/%s/%s", respuesta, lista_partidas->Partidas[idPartida].nombre2,lista_partidas->Partidas[idPartida].nombre3,lista_partidas->Partidas[idPartida].nombre4);
		}
		
		else if (lista_partidas->Partidas[idPartida].numJugadores == 5)
		{strcpy(lista_partidas->Partidas[idPartida].nombre5,jugador_origen);
		lista_partidas->Partidas[idPartida].sock[4] = GetSocket(lista,jugador_origen);
		sprintf(respuesta, "%s/%s/%s/%s/%s", respuesta, lista_partidas->Partidas[idPartida].nombre2,lista_partidas->Partidas[idPartida].nombre3,lista_partidas->Partidas[idPartida].nombre4,lista_partidas->Partidas[idPartida].nombre5);
		}
		
		else if (lista_partidas->Partidas[idPartida].numJugadores == 6)
		{strcpy(lista_partidas->Partidas[idPartida].nombre6,jugador_origen);
		lista_partidas->Partidas[idPartida].sock[5] = GetSocket(lista,jugador_origen);
		sprintf(respuesta, "%s/%s/%s/%s/%s/%s", respuesta, lista_partidas->Partidas[idPartida].nombre2,lista_partidas->Partidas[idPartida].nombre3,lista_partidas->Partidas[idPartida].nombre4,4,lista_partidas->Partidas[idPartida].nombre5,lista_partidas->Partidas[idPartida].nombre6);
		}
		
		printf("Jugador que invita:%s, Jugador invitado:%s\n",lista_partidas->Partidas[idPartida].nombre1,lista_partidas->Partidas[idPartida].nombre2);
	}
	else
	{
		sprintf(respuesta,"8/NO/%s No quiere jugar contigo",jugador_origen);
	}
	
	*sock_conn = socketDestino;
}
			
		//PETICIONES
		if (codigo == 0) //Desconectarse y eliminar de la lista de conectados, envia mensaje a todos los clientes conectados tal que: 5/ LISTA CONECTADOS
		{
			terminar = 1;
			desconectar=1;
			pthread_mutex_lock( &mutex );
			Desconectar(&milista,usuario,respuesta);
			Conectados(&milista,conectado);
			pthread_mutex_unlock( &mutex);
			
			char notificacion[512];
			sprintf(notificacion, "5/%s",conectado);
			printf("La respuesta es: %s\n", notificacion);
			
			int i;
			for (i=0; i < milista.num ; i++) 
				write (milista.conectados[i].socket, notificacion, strlen (notificacion));
		}
		
		else if (codigo == 1) //Inicio de sesi�n, envia la lista conectados para que la actualicen en el data grid view todos los usuarios conectdos
		{
			p=strtok(NULL,"/");
			strcpy(usuario,p); //snprintf
			p=strtok(NULL,"/");
			strcpy(contrasena,p);
			
			InicioSesion(usuario,contrasena, consulta, respuesta, codigo, conectado,sock_conn); //Lamamos a la funcion InicioSesion
			printf("La respuesta a iniciar session es: %s\n", respuesta);
			printf("Voy a sacar conectados \n");
			
			pthread_mutex_lock( &mutex );
			char conectados[300];
			Conectados(&milista, conectados);
			pthread_mutex_unlock( &mutex);
			char notificacion[512];
			sprintf(notificacion, "5/%s",conectados);
			printf("La respuesta es: %s\n", notificacion);
			
			int i;
			for (i=0; i < milista.num ; i++) 
				write (milista.conectados[i].socket, notificacion, strlen (notificacion));
		/*	printf("Respuesta: %s \n", respuesta);*/
			DameIdPartida(consulta, respuesta);
			
			desconectar=0;
			
		}
		else if(codigo==2) //Registro de nuevo usuario
		{
			p = strtok( NULL, "/");
			strcpy (usuario, p);
			p = strtok( NULL, "/");
			strcpy(contrasena,p);
			Registro(usuario,contrasena, respuesta, consulta, id);
			//Enviamos la respuesta
			printf("Respuesta: %s \n", respuesta);
			write(sock_conn, respuesta, strlen(respuesta));
			
			
		}
		else if(codigo ==3) //Envia mensaje con la duracion del chat 3/duracion
		{
            //Llamamos a la funcion Dameduracion
			Dameduracion(consulta,respuesta);
			write(sock_conn, respuesta, strlen(respuesta));
			
			
		}
		
		else if(codigo ==5) //Lista conectados
		{
		//lista conectados automatica
			printf("Voy a arrancar los nombres de usuario\n");
			pthread_mutex_lock( &mutex );
			char conectados[300];
			Conectados(&milista, conectados);
			pthread_mutex_unlock( &mutex);
			char notificacion[512];
			sprintf(notificacion, "5/%s",conectados);
			printf("La respuesta es: %s\n", notificacion);
			int i;
			for (i=0; i < milista.num ; i++) 
				write (milista.conectados[i].socket, notificacion, strlen (notificacion));
			
		}
		
		else if(codigo ==6) //envia cliente la ultima frase escrita en el chat.
		{   
		    //Llamamos funcion Dameultimafrase
			Dameultimafrase(consulta,respuesta);
			write(sock_conn, respuesta, strlen(respuesta));
			

		}
		if (codigo == 7) //Invitacion envia respuesta al cliente para saber si quiere iniciar un chat		{
			int socketOrigen;
			int socketDestino;
			char jugador_origen[20];
			char jugador_destino[20];
			//arrancamos nombre y buscamos socket con la funcion GetSocket
			p = strtok( NULL, "/");
			strcpy(jugador_origen,p);
			socketOrigen = GetSocket(&milista,jugador_origen);
			p = strtok (NULL,"/");
			strcpy(jugador_destino,p);
			socketDestino = GetSocket(&milista,jugador_destino);
			
			sprintf(respuesta,"7/%s/%s",jugador_origen, jugador_destino);
			write(socketDestino, respuesta, strlen(respuesta));
			printf("Respuesta: %s \n", respuesta);
			
		}
		
		if (codigo == 8) //Recepci�n de la invitaci�n, envia la respuesta usando la funcion anterior de VerificaInvitacion
		{
			int socketOrigen;
			int socketDestino;
			char res_invitacion[10];
			char jugador_origen[20];
			char jugador_destino[20];
			p = strtok( NULL, "/");
			strcpy(jugador_origen,p);
			socketOrigen = GetSocket(&milista,p);
			p= strtok (NULL,"/");
			strcpy(jugador_destino,p);
			socketDestino = GetSocket(&milista,p);
			printf("%d %d\n",socketDestino, socketOrigen);
			p=strtok(NULL,"/");
			strcpy(res_invitacion,p);
			
			pthread_mutex_lock( &mutex );
			VerificaInvitacion(&milista,&miListaPartidas,res_invitacion,socketOrigen,socketDestino,respuesta,jugador_origen,jugador_destino,&sock_conn);
			Conectados(&milista,conectado);
			pthread_mutex_unlock( &mutex);
			printf("Respuesta: %s \n", respuesta);
			write(socketDestino, respuesta, strlen(respuesta));
				
			
		}
				
		if (codigo==9)//Acabar el chat,inserta los valores obtenidos de duracion de chat y escribe la ultima frase a la base de datos
		{	
			int duracion;
			char mensaje[200];
			
			p = strtok( NULL, "/");
			strcpy(mensaje,p);
			p= strtok (NULL,"/");
			duracion = atoi(p);
			
			char insert[150];
			sprintf(insert, "INSERT INTO partidas (duracion, ultima_frase) VALUES (%d, '%s')", duracion, mensaje);
			
			err = mysql_query(conn, insert);
			if (err != 0) 
			{
				printf("Error al ejecutar la consulta: %s\n", mysql_error(conn));
			}
		    printf("insert=%s\n", insert);
			
			sprintf(consulta, "SELECT MAX(id_partidas) FROM partidas");
			printf("LA CONSULTA ES:%s\n", consulta);
			int err =mysql_query (conn, consulta);
			resultado = mysql_store_result (conn);
			row = mysql_fetch_row(resultado);
			if (row != NULL) {
				printf("Valor de id_partidas mas grande: %s\n", row[0]);
			} else {
				printf("No se encontraron registros en la tabla partidas.\n");
			}
			id_ultima_partida = atoi(row[0]);
			
			strcpy(respuesta,"10/");
			write (socketDestino,respuesta, strlen(respuesta));
			
		}
	}
	//cerramos conexion con servidor
	close(sock_conn);


//2 CONSULTAS:Dameduracion, Dameultimafrase

//Funcion Dameultimafrase: Tania
	
int Dameultimafrase(char consulta[200], char respuesta[200])//Funcion para la consulta 2, guarda en respuesta la ultima frase que dijo quien acab� el chat de manera 6/ultima frase
{	
	sprintf(consulta,"SELECT partidas.ultima_frase FROM partidas WHERE (id_partidas = %d)", id_ultima_partida);
	printf("Consulta SQL: %s\n", consulta);
	// Ejecutar la consulta
	if (mysql_query(conn, consulta) != 0)
	{
		printf("Error al consultar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	
	// Obtener el resultado de la consulta
	resultado = mysql_store_result(conn);
	// Verificar si se obtuvieron datos
	if (resultado == NULL)
	{
		printf("No se han obtenido datos en la consulta\n");
	}
	else
	{
		// Obtener la primera fila de resultados
		row = mysql_fetch_row(resultado);
		
		// Verificar si hay al menos una fila
		if (row != NULL)
		{
			// El resultado debe ser una matriz con una sola fila y una columna que contiene la ultima frase
			strcpy(ultima_Frase,(row[0]));
			
			// Utilizar sprintf para construir la respuesta
			sprintf(respuesta,"6/%s", ultima_Frase);
			
			printf("Ultima frase = %s\n", ultima_Frase);
		}
		else
		{
			printf("No se han obtenido datos en la consulta\n");
		}
		
		// Liberar el resultado
		mysql_free_result(resultado);
	}
	
	return ultima_Frase; 
}

//Funcion que retornara la duracion del chat: Laura
int Dameduracion(char consulta[200], char respuesta[200])
{
	printf("aaaaa\n");
	printf("id max= %d\n", id_ultima_partida);
	sprintf(consulta,"SELECT partidas.duracion FROM partidas WHERE (id_partidas = %d)", id_ultima_partida);
	printf("Consulta SQL: %s\n", consulta);
	if (mysql_query(conn, consulta) != 0)
	{
		printf("Error al consultar datos %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	
	// Obtenemos el resultado de la consulta
	resultado = mysql_store_result(conn);
	// Verificamos que obtuvimos datos
	if (resultado == NULL)
	{
		printf("No se han obtenido datos en la consulta\n");
	}
	else
	{
		
		row = mysql_fetch_row(resultado);
		
		if (row != NULL)
		{
		
			duracion_ultima_partida = atoi(row[0]);
			
			snprintf(respuesta, sizeof(respuesta), "3/%d", duracion_ultima_partida);
			
			printf("duracion = %d\n", duracion_ultima_partida);
		}
		else
		{
			printf("No se han obtenido datos en la consulta\n");
		}
		
		mysql_free_result(resultado);
	}
	
	return duracion_ultima_partida; 
}

}
int main(int argc, char *argv[])//Creamos el socket para la conexi�n
{
	int sock_conn, sock_listen;
	struct sockaddr_in serv_adr;
	
	if((sock_listen=socket(AF_INET, SOCK_STREAM, 0))<0)
		printf("Error creando el socket\n");
	
	memset(&serv_adr,0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(9070);//socket que usamos
	if(bind(sock_listen, (struct sockaddr *)&serv_adr, sizeof(serv_adr))<0)
		printf("Error al bind \n");
	
	if(listen(sock_listen, 100)<0)
		printf("Error en el listen \n");
	//Creamos la conexi�n con SQL
	conn = mysql_init(NULL);
	if (conn==NULL) 
	{
		printf ("Error al crear la conexion: %u %s\n", 
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	
	milista.num=0;
	
	
	//Inicializacion conexi�n
	conn = mysql_real_connect (conn, "shiva2.upc.es","root", "mysql", "Base_Datos_Juego_Laura_Tania_Alba",0, NULL, 0);
	if (conn==NULL) 
	{
		printf ("Error al inicializar la conexion: %u %s\n", 
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	
	contador=0;
	pthread_t thread;
	i=0;
	char usuario[20];
	
	for(;;) //bucle para atender a los clientes
	{
		printf("Escuchando \n");
		
		sock_conn=accept(sock_listen, NULL, NULL);
		printf("He recibido conexi�n\n");
		
		sockets[i]=sock_conn; //Socket que usaremos para este cliente
		
		pthread_create(&thread, NULL, Atencion,&sockets[i]); //Crear Thread
		i=i+1;	
	}	
}






