DROP DATABASE IF EXISTS Base_Datos_Juego_Laura_Tania_Alba;
CREATE DATABASE Base_Datos_Juego_Laura_Tania_Alba; 

USE Base_Datos_Juego_Laura_Tania_Alba;

CREATE TABLE jugadores (

   id_jugador INT PRIMARY KEY AUTO_INCREMENT,
   username VARCHAR(20) NOT NULL,
   pass VARCHAR(20) NOT NULL

)ENGINE=InnoDB;

CREATE TABLE partidas (

 id_partidas INT PRIMARY KEY AUTO_INCREMENT,
 duracion INT,
 ultima_frase VARCHAR(200)

)ENGINE=InnoDB;

CREATE TABLE participaciones (

 id_jugador INT,
 id_partida INT,
 FOREIGN KEY (id_jugador) REFERENCES jugadores(id_jugador),
 FOREIGN KEY (id_partida) REFERENCES partidas(id_partidas)

)ENGINE=InnoDB;

/*será nuestra tabla puente para saber cuantas partidas ha hecho X jugador
*/
INSERT INTO jugadores (username, pass) VALUES ('user1', '4321');
INSERT INTO jugadores (username, pass) VALUES ('user2', '1234');
INSERT INTO jugadores (username, pass) VALUES ('user3', '1234');


INSERT INTO partidas (duracion, ultima_frase) VALUES (3, '-Me: Hola');
INSERT INTO partidas (duracion, ultima_frase) VALUES (1, '-user3: Como estas?');
INSERT INTO partidas (duracion, ultima_frase) VALUES (6, '-user3:Entiendo');
INSERT INTO partidas (duracion, ultima_frase) VALUES (3, '-user1: Okey');
INSERT INTO partidas (duracion, ultima_frase) VALUES (3, '-user2: Adios');

 
/*INSERT INTO participaciones VALUES (1,1);*/
INSERT INTO participaciones VALUES (5,1);
INSERT INTO participaciones VALUES (4,2);
INSERT INTO participaciones VALUES (3,3);
INSERT INTO participaciones VALUES (2,4);
INSERT INTO participaciones VALUES (1,5);





